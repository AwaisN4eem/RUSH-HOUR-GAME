
**********************For UBUNTU LATEST VERSION(22.04.02)*******************************************

TO RUN THIS GAME,YOU HAVE FOLLOW THESE STEPS:
1- Unzip folder.
2- Open terminal in this folder.
3- Write this in terminal: 
bash install-libraries.sh
Then hit enter.

After that , write following and then hit enter :
make

At last ,write following and then hit enter:
./game

********************For Ubuntu OLDER Versions***************************************************

To execute the starter code, you need to do the following:
a) Extract the attached zip file. 
b) Open the terminal and navigate to the path of extracted directory
c) Install the required libraries by executing the command below:
 bash install-libraries.sh
d) Compile the project by writing the command
 make
e) Run the main file 
 ./game
 
 NOTE:All logic is implemented in game.cpp
 
